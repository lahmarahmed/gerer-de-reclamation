declare module 'stompjs';
declare module 'sockjs-client';