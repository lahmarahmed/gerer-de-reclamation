// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  KEY: 'd3eb0fbffa38fd285ba6a167945d44e8',
  TOKEN: '211b8fe300b1ead2ac64c4ef456dbb59b234919d83d23d246a2d7df319c1b5e9',
  firebaseConfig :{
    apiKey: "AIzaSyDgLb_3GNoPJMT7Xywl89m2AXi8N9c0Xso",
    authDomain: "angular-chat-app-a0bad.firebaseapp.com",
    databaseURL: "https://angular-chat-app-a0bad-default-rtdb.firebaseio.com",
    projectId: "angular-chat-app-a0bad",
    storageBucket: "angular-chat-app-a0bad.appspot.com",
    messagingSenderId: "711699271680",
    appId: "1:711699271680:web:58c3b7d9401b22b24c08e5"
  }
  /*idListToDo:'6255e826c9e8363516e65883',
  idListDoing:'6255e826c9e8363516e65883',
  idListDone:'6255e826c9e8363516e65885'*/
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
