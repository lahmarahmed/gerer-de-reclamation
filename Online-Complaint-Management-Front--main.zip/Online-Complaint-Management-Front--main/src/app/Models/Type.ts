export interface Type{
    type_id: string;
    type: string;
}