export interface Status{
    id: string;
    status: string;
    dateCreation: Date
}