export enum Etat {
	EN_COURS = 'EN_COURS',
	EN_ATTENTE = 'EN_ATTENTE',
	ClOTURE = 'ClOTURE'
}