export interface Filter {
    name:string;
    options:string[];
    defaultValue:string;
}

export interface filterOption{
    name:string;
    value:string;
    isdefault:boolean;
}
