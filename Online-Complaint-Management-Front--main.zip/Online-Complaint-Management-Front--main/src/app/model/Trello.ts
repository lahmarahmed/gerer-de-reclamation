export class TrelloDB {
    idBoard : string;	
    idListToDo:string;	
    idListDoing:string;	
    idListDone:string;
    projet:number	
  }
  