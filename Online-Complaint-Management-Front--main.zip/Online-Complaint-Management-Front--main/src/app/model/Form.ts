export class Form{ 
	nickname:string;
	title: string;
}
